import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../store/gameStore';
import PlayerColumn from './PlayerColumn';
import NumberPicker from './NumberPicker';
import ShootingModal from './ShootingModal';
import GameLog from './GameLog';
import toast from 'react-hot-toast';
import ReactConfetti from 'react-confetti';

const GameArena: React.FC = () => {
  const { 
    currentRoom,
    username,
    performGameAction
  } = useGameStore();

  const scrollRef = useRef<HTMLDivElement>(null);
  const [showShootingModal, setShowShootingModal] = React.useState(false);
  const [selectedCell, setSelectedCell] = React.useState<number | null>(null);
  const [windowSize, setWindowSize] = React.useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = 0;
    }
  }, [currentRoom?.gameState?.currentPlayer]);

  if (!currentRoom || !currentRoom.gameState) return null;

  const currentPlayerIndex = currentRoom.gameState.currentPlayer;
  const currentPlayer = currentRoom.gameState.players[currentPlayerIndex];
  const isMyTurn = currentRoom.players[currentPlayerIndex].username === username;
  
  const handleNumberPick = (value: number) => {
    if (!isMyTurn) return;
    performGameAction('roll', { value });
  };

  const handleShoot = (targetPlayer: number, targetCell: number) => {
    if (!isMyTurn || selectedCell === null) return;
    
    const sourceCell = currentPlayer.cells[selectedCell];
    if (sourceCell.stage === 6 && sourceCell.bullets > 0) {
      performGameAction('shoot', { 
        targetPlayer,
        targetCell,
        sourceCell: selectedCell 
      });
      setShowShootingModal(false);
      setSelectedCell(null);
    } else {
      toast.error("This cell cannot shoot!");
    }
  };

  const handleCellClick = (cellIndex: number) => {
    if (!isMyTurn) return;
    const cell = currentPlayer.cells[cellIndex];
    
    if (cell.stage === 6 && cell.bullets > 0) {
      setSelectedCell(cellIndex);
      setShowShootingModal(true);
    } else if (cell.stage === 6) {
      toast.error("This cell has no bullets!");
    }
  };

  useEffect(() => {
    if (isMyTurn) {
      toast.success("It's your turn!", {
        icon: '🎲',
        duration: 3000,
      });
    }
  }, [currentPlayerIndex, isMyTurn]);

  const winner = currentRoom.gameState.players.find(p => 
    !p.eliminated && currentRoom.gameState.players.filter(op => !op.eliminated).length === 1
  );

  return (
    <div className="min-h-screen bg-background text-foreground p-4 lg:p-8">
      <div className="max-w-[1920px] mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-secondary/10 backdrop-blur-lg rounded-xl p-4 lg:p-8 shadow-2xl"
        >
          {winner && (
            <ReactConfetti
              width={windowSize.width}
              height={windowSize.height}
              recycle={false}
              numberOfPieces={500}
            />
          )}
          
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold mb-2">Dice Battle Arena</h1>
            <div className="flex items-center justify-center gap-4">
              <p className="text-primary">
                Current Turn: <span className="font-bold">
                  {currentRoom.players[currentPlayerIndex].username}
                  {isMyTurn ? " (You)" : ""}
                </span>
              </p>
            </div>
          </div>

          <GameLog gameLog={currentRoom.gameState.gameLog} />

          <div 
            ref={scrollRef}
            className="overflow-x-auto pb-4 mb-8 snap-x snap-mandatory"
          >
            <div className="flex gap-4 min-w-max">
              {currentRoom.gameState.players.map((player, index) => (
                <div key={player.id} className="snap-start">
                  <PlayerColumn
                    player={player}
                    isCurrentPlayer={currentPlayerIndex === index}
                    onCellClick={handleCellClick}
                    isMyTurn={isMyTurn}
                    numCells={currentRoom.players.length}
                  />
                </div>
              ))}
            </div>
          </div>

          {!winner && isMyTurn && (
            <div className="mt-8 flex justify-center">
              <NumberPicker
                maxNumber={currentRoom.players.length}
                onPick={handleNumberPick}
                disabled={showShootingModal || currentPlayer.eliminated}
                firstMove={currentPlayer.firstMove}
              />
            </div>
          )}

          <AnimatePresence>
            {showShootingModal && (
              <ShootingModal
                players={currentRoom.gameState.players}
                currentPlayer={currentPlayerIndex}
                onShoot={handleShoot}
                onClose={() => {
                  setShowShootingModal(false);
                  setSelectedCell(null);
                }}
              />
            )}
          </AnimatePresence>

          {winner && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-8 text-center"
            >
              <h2 className="text-3xl font-bold mb-4">
                🎉 {winner.username} Wins! 🎉
              </h2>
              <p className="text-primary">
                {winner.username === username ? 
                  "Congratulations! You've dominated the Battle Arena!" : 
                  `${winner.username} has dominated the Battle Arena!`}
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default GameArena;