# Dice Battle Arena Server

Multiplayer game server using Socket.IO and Express.

## Setup

```bash
npm install
npm start
```

## Environment Variables

- `PORT`: Server port (default: 3000)
- `NODE_ENV`: Environment (development/production)